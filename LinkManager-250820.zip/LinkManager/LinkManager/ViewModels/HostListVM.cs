﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinkManager.Models;

namespace LinkManager.ViewModels
{
    public class HostListVM
    {
        public ObservableCollection<DocInfoRvtHost> RvtHostListVM { get; } = new();

        public void AddHost(DocInfoRvtHost docInfoRvtHost)
        {
            // RvtHostListVM에 입력된 것과 동일한 요소가 존재하는지 판단하고 없으면 추가
            bool exists = RvtHostListVM.Any(h => h.FullPath.Equals(docInfoRvtHost.FullPath, StringComparison.OrdinalIgnoreCase));
            if (!exists)
            {
                RvtHostListVM.Add(docInfoRvtHost);
            }
        }

        public void RemoveHost(DocInfoRvtHost docInfoRvtHost)
        {
            RvtHostListVM.Remove(docInfoRvtHost);
        }

    }
}