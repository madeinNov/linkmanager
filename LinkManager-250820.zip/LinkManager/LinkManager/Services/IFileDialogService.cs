﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkManager.Services
{
    public interface IFileDialogService
    {
        string GetFile(string extension);
        List<string> GetFiles(string extension);
    }

    public class FileDialogService : IFileDialogService
    {
        public string GetFile(string extension)
        {
            var dialog = new OpenFileDialog
            {
                Filter = CreateFilter(extension),
                Multiselect = false
            };
            bool? result = dialog.ShowDialog();

            if (result == true)
            {
                return dialog.FileName;
            }
            else
            {
                return null;
            }
        }

        public List<string> GetFiles(string extension)
        {
            var dialog = new OpenFileDialog
            {
                Filter = CreateFilter(extension),
                Multiselect = true
            };
            bool? result = dialog.ShowDialog();

            if (result == true)
            {
                return new List<string>(dialog.FileNames);
            }
            else
            {
                return null;
            }
        }


        // Dialog Filter helper
        private static string CreateFilter(string extension)
        {
            if (string.IsNullOrWhiteSpace(extension))
            {
                return "All Files (*.*)|*.*";
            }

            extension = extension.Trim().TrimStart('.');
            string desc = extension.ToUpper() + " Files";

            return $"{desc} (*.{extension})|*.{extension}";
        }
    }
}