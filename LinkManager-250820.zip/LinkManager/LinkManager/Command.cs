﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using LinkManager.Models;
using LinkManager.Services;
using LinkManager.ViewModels;
using LinkManager.Views;
using System.Windows;

namespace LinkManager
{
    [Transaction(TransactionMode.Manual)]
    class Command : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;

            IFileDialogService fileDialogService = new FileDialogService();

            HostListVM hostListVM = new HostListVM();

            foreach (string st in fileDialogService.GetFiles("rvt"))
            {
                hostListVM.AddHost(new DocInfoRvtHost(st));
            }

            TaskDialog.Show("d", $"{hostListVM.RvtHostListVM[0].FullPath}");


            //// TestFileDialogService 
            //TestFileDialogService testFileDialogService = new TestFileDialogService();
            //testFileDialogService.ShowDialog();


            return Result.Succeeded;
        }
    }
}