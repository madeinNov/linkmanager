﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkManager.Models
{
    public class DocInfo
    {
        public string FullPath { get; }
        public string FileName { get; } // a.rvt
        public string BaseName { get; } // a
        public string Extension { get; } // .rvt
        public long SizeInBytes { get; }
        public DateTime LastModified { get; }
        public DateTime LastModifiedUtc { get; }
        public bool IsMissing { get; }

        public DocInfo(string docPath)
        {
            FullPath = System.IO.Path.GetFullPath(docPath);
            IsMissing = !System.IO.File.Exists(FullPath);
            FileName = System.IO.Path.GetFileName(FullPath);
            BaseName = System.IO.Path.GetFileNameWithoutExtension(FileName);
            Extension = System.IO.Path.GetExtension(FileName)?.ToLowerInvariant() ?? "";
        }
    }
}
