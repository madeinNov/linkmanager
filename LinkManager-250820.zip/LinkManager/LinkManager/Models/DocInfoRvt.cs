﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace LinkManager.Models
{
    public class DocInfoRvt : DocInfo
    {
        public bool IsWorkshared { get; }

        public DocInfoRvt(string docPath) : base(docPath)
        {
            if (!IsMissing && Extension == ".rvt") // RVT파일인 경우 Workshared 판정 시도
            {
                IsWorkshared = BasicFileInfo.Extract(FullPath).IsWorkshared;

            }
            else
            {
                IsWorkshared = false;
            }
        }
    }
}
