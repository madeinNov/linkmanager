﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinkManager.Models;

namespace LinkManager.ViewModels
{
    public class HostVM
    {
        public string testst { get; } = "ddddddd";
        public ObservableCollection<DocInfoRvtLink> RvtLinkListVM { get; } = new();
        public DocInfoRvtHost docInfoRvtHost { get; } // 원본 Model
        public string FullPathVM => docInfoRvtHost.FullPath;
        public string FileNameVM => docInfoRvtHost.FileName;
        public HostVM() 
        {
        }
        public HostVM(DocInfoRvtHost docInfoRvtHost)
        {
            this.docInfoRvtHost = docInfoRvtHost;
            RvtLinkListVM = new ObservableCollection<DocInfoRvtLink>(docInfoRvtHost.RvtLinkList);
        }

        public void AddLink(DocInfoRvtLink docInfoRvtLink)
        {
            RvtLinkListVM.Add(docInfoRvtLink);
        }
        public void RemoveLink(DocInfoRvtLink docInfoRvtLink)
        {
            RvtLinkListVM.Remove(docInfoRvtLink);
        }
    }
}
