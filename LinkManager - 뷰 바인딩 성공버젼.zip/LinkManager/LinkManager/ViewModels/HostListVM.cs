﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinkManager.Models;

namespace LinkManager.ViewModels
{
    public class HostListVM
    {
        public ObservableCollection<DocInfoRvtHost> RvtLinkHostVM { get; } = new();

        public void AddHost(DocInfoRvtHost docInfoRvtHost)
        {
            foreach (var h in RvtLinkHostVM) // 같은 FullPath의 Hosts 중복 방지
            {
                if (h.FullPath.Equals(docInfoRvtHost.FullPath, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }
        }

        public void RemoveHost(DocInfoRvtHost docInfoRvtHost)
        {
            RvtLinkHostVM.Remove(docInfoRvtHost);
        }

    }
}
