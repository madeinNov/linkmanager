﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace LinkManager.Models
{
    public class DocInfoRvtLink : DocInfoRvt
    {
        public string SavedPath { get; }
        public PathType pathType { get; }
        public LinkedFileStatus linkedFileStatus { get; }
        public ExternalFileReferenceType? RefType { get; }
        public long? LinkTypeId { get; }
        public DocInfoRvtLink(ExternalFileReference extRef)
            : base(ModelPathUtils.ConvertModelPathToUserVisiblePath(extRef.GetAbsolutePath()))
        {
            SavedPath = ModelPathUtils.ConvertModelPathToUserVisiblePath(extRef.GetPath());
            pathType = extRef.PathType;
            linkedFileStatus = extRef.GetLinkedFileStatus();
            RefType = extRef.ExternalFileReferenceType;
        }
    }
}
