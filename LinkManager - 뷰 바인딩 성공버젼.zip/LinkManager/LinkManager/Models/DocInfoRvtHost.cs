﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;

namespace LinkManager.Models
{
    public class DocInfoRvtHost : DocInfoRvt
    {
        public IList<DocInfoRvtLink> RvtLinkList = new ObservableCollection<DocInfoRvtLink>();
        public DocInfoRvtHost(string docPath) : base(docPath)
        {
            ModelPath modelPath = ModelPathUtils.ConvertUserVisiblePathToModelPath(FullPath);
            TransmissionData transmissionData = TransmissionData.ReadTransmissionData(modelPath);

            foreach (ElementId refId in transmissionData.GetAllExternalFileReferenceIds())
            {
                ExternalFileReference extRef = transmissionData.GetLastSavedReferenceData(refId);

                string linkAbsolutePath = ModelPathUtils.ConvertModelPathToUserVisiblePath(extRef.GetAbsolutePath());
                                
                if (linkAbsolutePath.EndsWith(".rvt", StringComparison.OrdinalIgnoreCase)) // RVT 링크만 수집
                {
                    DocInfoRvtLink docInfoRvtLink = new DocInfoRvtLink(extRef);
                    RvtLinkList.Add(docInfoRvtLink);
                }
            }
        }
    }
}
